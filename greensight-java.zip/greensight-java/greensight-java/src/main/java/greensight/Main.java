package greensight;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

public class Main {
    public static void main(String[] args) throws IOException {
        HttpServer server = HttpServer.create(new InetSocketAddress(8081), 0);

        // Открываем страницу регистрации
        server.createContext("/", exchange -> {
            if (!exchange.getRequestURI().getPath().equals("/")) {
                sendResponse(exchange, 404, "Страница не найдена", "text/plain; charset=UTF-8");
                return;
            }

            byte[] page = Files.readAllBytes(Path.of("src/main/resources/static/index.html"));
            exchange.getResponseHeaders().set("Content-Type", "text/html; charset=UTF-8");
            exchange.sendResponseHeaders(200, page.length);
            exchange.getResponseBody().write(page);
            exchange.close();
        });

        // Обрабатываем AJAX-запрос регистрации
        server.createContext("/register", exchange -> {
            if (!exchange.getRequestMethod().equalsIgnoreCase("POST")) {
                sendJson(exchange, 405, false, "Используйте POST-запрос");
                return;
            }

            Map<String, String> data = readFormData(exchange);
            String name = data.getOrDefault("name", "").trim();
            String surname = data.getOrDefault("surname", "").trim();
            String email = data.getOrDefault("email", "").trim();
            String password = data.getOrDefault("password", "");
            String repeatPassword = data.getOrDefault("repeatPassword", "");

            String error = validate(name, surname, email, password, repeatPassword);
            if (error != null) {
                writeLog("Ошибка регистрации: " + error + ", email=" + email);
                sendJson(exchange, 400, false, error);
                return;
            }

            // Пример массива уже существующих пользователей
            User[] users = {
                    new User(1, "Иван", "ivan@example.com"),
                    new User(2, "Мария", "maria@example.com"),
                    new User(3, "Петр", "petr@example.com")
            };

            for (User user : users) {
                if (user.email.equalsIgnoreCase(email)) {
                    writeLog("Ошибка регистрации: email уже существует, email=" + email);
                    sendJson(exchange, 400, false, "Пользователь с таким email уже существует");
                    return;
                }
            }

            writeLog("Успешная регистрация: name=" + name + ", surname=" + surname + ", email=" + email);
            sendJson(exchange, 200, true, "Регистрация прошла успешно!");
        });

        server.start();
        System.out.println("Сервер запущен: http://localhost:8081");
    }

    // Проверка введённых данных
    private static String validate(String name, String surname, String email,
                                   String password, String repeatPassword) {
        if (name.isEmpty() || surname.isEmpty() || email.isEmpty()
                || password.isEmpty() || repeatPassword.isEmpty()) {
            return "Заполните все поля";
        }
        if (!email.contains("@")) {
            return "Email должен содержать символ @";
        }
        if (!password.equals(repeatPassword)) {
            return "Пароли не совпадают";
        }
        return null;
    }

    // Читаем данные, отправленные формой
    private static Map<String, String> readFormData(HttpExchange exchange) throws IOException {
        String body = new String(exchange.getRequestBody().readAllBytes(), StandardCharsets.UTF_8);
        Map<String, String> result = new HashMap<>();

        for (String pair : body.split("&")) {
            String[] parts = pair.split("=", 2);
            String key = URLDecoder.decode(parts[0], StandardCharsets.UTF_8);
            String value = parts.length > 1
                    ? URLDecoder.decode(parts[1], StandardCharsets.UTF_8) : "";
            result.put(key, value);
        }
        return result;
    }

    // Записываем результат в лог-файл
    private static void writeLog(String message) {
        try {
            Files.createDirectories(Path.of("logs"));
            String logLine = LocalDateTime.now() + " - " + message + System.lineSeparator();
            Files.writeString(Path.of("logs/registration.log"), logLine,
                    StandardCharsets.UTF_8,
                    java.nio.file.StandardOpenOption.CREATE,
                    java.nio.file.StandardOpenOption.APPEND);
        } catch (IOException e) {
            System.out.println("Не удалось записать лог: " + e.getMessage());
        }
    }

    // Отправляем JSON-ответ клиенту
    private static void sendJson(HttpExchange exchange, int status,
                                 boolean success, String message) throws IOException {
        String json = "{\"success\":" + success + ",\"message\":\""
                + message.replace("\\", "\\\\").replace("\"", "\\\"") + "\"}";
        sendResponse(exchange, status, json, "application/json; charset=UTF-8");
    }

    private static void sendResponse(HttpExchange exchange, int status,
                                     String response, String contentType) throws IOException {
        byte[] bytes = response.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", contentType);
        exchange.sendResponseHeaders(status, bytes.length);
        exchange.getResponseBody().write(bytes);
        exchange.close();
    }
}
